package name.cdd.product.kafka.pftest.xml;

import java.io.File;

public class ConfFileReader
{
    private static final ConfFileReader intance = new ConfFileReader();
    
    private XmlIO io;

    private ConfFileReader()
    {
        this.io = new XmlIO(new File("conf.xml"));
    }
    
    public static ConfFileReader getInstance()
    {
        return intance;
    }
    
    public int getThreads()
    {
        String threads = io.getElement("frequency", "threads").getText();
        return Integer.parseInt(threads);
    }
}
